var structflaglist =
[
    [ "flag", "structflaglist.html#afe3283978a321862c7c7705e13206672", null ],
    [ "name", "structflaglist.html#a7759b95e8ccf9db09a3a3b839468be71", null ]
];