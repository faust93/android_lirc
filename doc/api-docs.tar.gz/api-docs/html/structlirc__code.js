var structlirc__code =
[
    [ "button", "structlirc__code.html#a2ee8d5ea2038ad6f230cae2162c3c5b6", null ],
    [ "next", "structlirc__code.html#a76825229dac6c89de987508307716425", null ],
    [ "remote", "structlirc__code.html#aac68caddd2323987655c1504662ae3fe", null ]
];