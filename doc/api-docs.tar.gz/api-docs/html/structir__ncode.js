var structir__ncode =
[
    [ "code", "structir__ncode.html#a17ca9e939fd5742de3ed6e29bdc68e8d", null ],
    [ "current", "structir__ncode.html#a849807a18ac00c5d4228c2ebf5eb6519", null ],
    [ "length", "structir__ncode.html#a46824261611491c5ff0b611cda1ec437", null ],
    [ "name", "structir__ncode.html#ac28e8133cbc7aa22dbbc8ef722883d2b", null ],
    [ "next", "structir__ncode.html#a0e80278912121f630d3b398959c4dad7", null ],
    [ "signals", "structir__ncode.html#a6ff318262c9447b1e1fc4e944e29bf4a", null ],
    [ "transmit_state", "structir__ncode.html#a29cc93e9a6e908dfe8904db34680ef1f", null ]
];