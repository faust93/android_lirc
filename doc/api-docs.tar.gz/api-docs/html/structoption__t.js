var structoption__t =
[
    [ "key", "structoption__t.html#a77ffef1a45ea4d73c9da6de96c12e13a", null ],
    [ "value", "structoption__t.html#a3133b9533f1b24597f947cff736460b2", null ]
];