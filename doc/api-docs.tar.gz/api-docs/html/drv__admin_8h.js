var drv__admin_8h =
[
    [ "PLUGIN_FILE_EXTENSION", "drv__admin_8h.html#a0e76aa2798ba27e3af5dd41602335467", null ],
    [ "drv_guest_func", "drv__admin_8h.html#ab2d7f4aa35dfb02d7f2eaadadd039755", null ],
    [ "plugin_guest_func", "drv__admin_8h.html#acab954e0e5cb544c43587fdcbb1331fa", null ],
    [ "for_each_driver", "drv__admin_8h.html#a6611f353b900834d1db0df47632be2ef", null ],
    [ "for_each_plugin", "drv__admin_8h.html#a9b76aa2090cad96593984bd833c3484c", null ],
    [ "hw_choose_driver", "drv__admin_8h.html#a1eaff4902d2d278d2d42e47e763c89da", null ],
    [ "hw_print_drivers", "drv__admin_8h.html#af73a4ec1270778bae0a0376af1c79b6b", null ]
];