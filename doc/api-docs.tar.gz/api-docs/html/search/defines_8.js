var searchData=
[
  ['raw_5fcodes',['RAW_CODES',['../ir__remote__types_8h.html#a1d5942b879cf0bb135f4496bb0d27d4a',1,'ir_remote_types.h']]],
  ['rc5',['RC5',['../ir__remote__types_8h.html#a91697bfec209fb3146fde1f40e425ede',1,'ir_remote_types.h']]],
  ['rc6',['RC6',['../ir__remote__types_8h.html#a259ca3c51823b7454fb93db646b81bb1',1,'ir_remote_types.h']]],
  ['rcmm',['RCMM',['../ir__remote__types_8h.html#ad67f2feebcdfc52e6342da7cb1c8f997',1,'ir_remote_types.h']]],
  ['repeat_5fheader',['REPEAT_HEADER',['../ir__remote__types_8h.html#a2c2f13c03a7d50bc96caf3d4c52ee084',1,'ir_remote_types.h']]],
  ['repeat_5fmax_5fdefault',['REPEAT_MAX_DEFAULT',['../ir__remote__types_8h.html#abc1771f65e11778c1f1cd8c7dd44506e',1,'ir_remote_types.h']]]
];
