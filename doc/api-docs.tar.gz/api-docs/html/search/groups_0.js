var searchData=
[
  ['ciniparser',['Ciniparser',['../group__ciniparser.html',1,'']]],
  ['client_20api_20manual_20excerpt_2e',['Client API manual excerpt.',['../group__client__manual.html',1,'']]],
  ['client_20api',['Client API',['../group__lirc__client.html',1,'']]]
];
