var searchData=
[
  ['gap',['gap',['../structir__remote.html#ab4e0daf0c0bb06e3feb707c401c92c0e',1,'ir_remote']]],
  ['gap2',['gap2',['../structir__remote.html#a096b15218256835f369f4fa701151971',1,'ir_remote']]]
];
