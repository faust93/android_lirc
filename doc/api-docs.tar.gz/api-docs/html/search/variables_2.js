var searchData=
[
  ['close_5ffunc',['close_func',['../structdriver.html#a5217ca972f2a1fc8e7bc04a67ef73bd7',1,'driver']]],
  ['code',['code',['../structir__ncode.html#a17ca9e939fd5742de3ed6e29bdc68e8d',1,'ir_ncode::code()'],['../structdecode__ctx__t.html#a1a206e5968a38e6e5286be41c037c30c',1,'decode_ctx_t::code()']]],
  ['code_5flength',['code_length',['../structdriver.html#a2ee468d3e45ec38ceb8a8122a721c2ae',1,'driver']]],
  ['curr_5fdriver',['curr_driver',['../driver_8c.html#ad91d56c6105bc2b6a4ae984b35095307',1,'curr_driver():&#160;driver.c'],['../driver_8h.html#a0396ff8d348a185f66f5096ee4f275d5',1,'curr_driver():&#160;driver.c']]],
  ['current',['current',['../structir__ncode.html#a849807a18ac00c5d4228c2ebf5eb6519',1,'ir_ncode']]]
];
