var searchData=
[
  ['decode_5fall',['decode_all',['../group__driver__api.html#gae334c37e486ce414abf272d4850df6c4',1,'decode_all(struct ir_remote *remotes):&#160;ir_remote.c'],['../group__driver__api.html#gae334c37e486ce414abf272d4850df6c4',1,'decode_all(struct ir_remote *remotes):&#160;ir_remote.c']]],
  ['default_5fclose',['default_close',['../group__driver__api.html#ga683dd53e7e5d62746c1a645fe133daf0',1,'default_close():&#160;driver.c'],['../group__driver__api.html#ga683dd53e7e5d62746c1a645fe133daf0',1,'default_close(void):&#160;driver.c']]],
  ['default_5fdrvctl',['default_drvctl',['../group__driver__api.html#ga96e3243bc45ff488f6c55dde5e9b377b',1,'default_drvctl(unsigned int fd, void *arg):&#160;driver.c'],['../group__driver__api.html#ga96e3243bc45ff488f6c55dde5e9b377b',1,'default_drvctl(unsigned int cmd, void *arg):&#160;driver.c']]],
  ['default_5fopen',['default_open',['../group__driver__api.html#gac0f7baaef9fe524365c16022001804d3',1,'default_open(const char *path):&#160;driver.c'],['../group__driver__api.html#gac0f7baaef9fe524365c16022001804d3',1,'default_open(const char *path):&#160;driver.c']]],
  ['dictionary_5fdel',['dictionary_del',['../group__ciniparser.html#ga9d792f2544cf674a371663e2f32128fa',1,'dictionary.c']]],
  ['dictionary_5fdump',['dictionary_dump',['../group__ciniparser.html#ga6e29ecf9c79331b1c6c26cd662cba042',1,'dictionary.c']]],
  ['dictionary_5fget',['dictionary_get',['../group__ciniparser.html#ga9b891a858ce598f8c87e3312d47bb2fc',1,'dictionary.c']]],
  ['dictionary_5fhash',['dictionary_hash',['../group__ciniparser.html#ga7c1ef0a729e668d1e8d6a7e774feaf2e',1,'dictionary.c']]],
  ['dictionary_5fnew',['dictionary_new',['../group__ciniparser.html#ga876a908eb786f957f939a08a362e514d',1,'dictionary.c']]],
  ['dictionary_5fset',['dictionary_set',['../group__ciniparser.html#gaab65a95ad09062716b24a129d8529b76',1,'dictionary.c']]],
  ['dictionary_5funset',['dictionary_unset',['../group__ciniparser.html#ga27f0752948d52ccd2568dae22f5db2bc',1,'dictionary.c']]],
  ['drv_5fhandle_5foptions',['drv_handle_options',['../group__driver__api.html#gaae1b223d2bd3a0d0be6e77019c9a976c',1,'drv_handle_options(const char *options):&#160;driver.c'],['../group__driver__api.html#gaae1b223d2bd3a0d0be6e77019c9a976c',1,'drv_handle_options(const char *options):&#160;driver.c']]]
];
