var searchData=
[
  ['waitfordata',['waitfordata',['../group__driver__api.html#gadcb46dccea6a4f82bebda46e51945819',1,'waitfordata(__u32 maxusec):&#160;receive.c'],['../group__driver__api.html#gadcb46dccea6a4f82bebda46e51945819',1,'waitfordata(__u32 maxusec):&#160;receive.c']]],
  ['write_5fmessage',['write_message',['../group__driver__api.html#ga04461705747fd8521d369ee96ed762fe',1,'write_message(char *buffer, size_t size, const char *remote_name, const char *button_name, const char *button_suffix, ir_code code, int reps):&#160;ir_remote.c'],['../group__driver__api.html#ga04461705747fd8521d369ee96ed762fe',1,'write_message(char *buffer, size_t size, const char *remote_name, const char *button_name, const char *button_suffix, ir_code code, int reps):&#160;ir_remote.c']]]
];
