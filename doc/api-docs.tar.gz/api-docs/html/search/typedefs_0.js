var searchData=
[
  ['dictionary',['dictionary',['../group__ciniparser.html#ga5bd3b2ce42b776c76755ec65642f43af',1,'dictionary.h']]],
  ['drv_5fguest_5ffunc',['drv_guest_func',['../drv__admin_8h.html#ab2d7f4aa35dfb02d7f2eaadadd039755',1,'drv_admin.h']]]
];
