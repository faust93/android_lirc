var searchData=
[
  ['plugin_5fguest_5ffunc',['plugin_guest_func',['../drv__admin_8h.html#acab954e0e5cb544c43587fdcbb1331fa',1,'drv_admin.h']]]
];
