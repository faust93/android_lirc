var searchData=
[
  ['options_5fset_5floglevel',['options_set_loglevel',['../lirc__options_8c.html#a21ea46a90d52096ab0a309317312b346',1,'options_set_loglevel(const char *optarg):&#160;lirc_options.c'],['../lirc__options_8h.html#a21ea46a90d52096ab0a309317312b346',1,'options_set_loglevel(const char *optarg):&#160;lirc_options.c']]]
];
