var structdriver =
[
    [ "api_version", "structdriver.html#a16e4dc8d1f027390afd91294991d932d", null ],
    [ "close_func", "structdriver.html#a5217ca972f2a1fc8e7bc04a67ef73bd7", null ],
    [ "code_length", "structdriver.html#a2ee468d3e45ec38ceb8a8122a721c2ae", null ],
    [ "decode_func", "structdriver.html#a761099e25fcbf8f0ca9a5b45fbd1f5fc", null ],
    [ "deinit_func", "structdriver.html#ac1ac9d52e4ef2c7ce3cd05a3536d7875", null ],
    [ "device", "structdriver.html#aca3bbacc48c5f27dac5568bd658afec8", null ],
    [ "driver_version", "structdriver.html#a2c48ed8680d2f242dd0c018f846551b7", null ],
    [ "drvctl_func", "structdriver.html#a84ea3e16dbac1e5cf03d202f6a68a265", null ],
    [ "fd", "structdriver.html#a277e91c9ef0365654b5412cdcf8cac5f", null ],
    [ "features", "structdriver.html#acefa919d82609175b57967c5249020c0", null ],
    [ "info", "structdriver.html#a6b71523700af552255b059ff51a657e1", null ],
    [ "init_func", "structdriver.html#a5881deaf612c76c067198a3a155cc225", null ],
    [ "name", "structdriver.html#a2d4bc5861fb0d7bb1684e22a16b7d414", null ],
    [ "open_func", "structdriver.html#a2a18e73cac86ce83a5748849f3741c43", null ],
    [ "readdata", "structdriver.html#acceaeac79f85c154d75449977e54e29d", null ],
    [ "rec_func", "structdriver.html#a319f12b62f2271a8249b497eabe45ae5", null ],
    [ "rec_mode", "structdriver.html#ad5d91256e4b5eb5139a6a744cc8204f6", null ],
    [ "resolution", "structdriver.html#a91eef0a66c9eb8ba1d3c8c9f69a1086b", null ],
    [ "send_func", "structdriver.html#a343a64e118c2d03110579124f509c0e2", null ],
    [ "send_mode", "structdriver.html#abad2a6f422a77f0b80848085b2512ca4", null ]
];