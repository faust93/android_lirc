var dictionary_8c =
[
    [ "DICT_INVALID_KEY", "group__ciniparser.html#ga220dbd9af990c8faebfd01bd62b2dde4", null ],
    [ "DICTMINSZ", "group__ciniparser.html#gaaf4ab97b3163920286cb932a3faedf86", null ],
    [ "MAXVALSZ", "group__ciniparser.html#ga071228a4e1c69ac2eec59e9c1385185a", null ],
    [ "dictionary_del", "group__ciniparser.html#ga9d792f2544cf674a371663e2f32128fa", null ],
    [ "dictionary_dump", "group__ciniparser.html#ga6e29ecf9c79331b1c6c26cd662cba042", null ],
    [ "dictionary_get", "group__ciniparser.html#ga9b891a858ce598f8c87e3312d47bb2fc", null ],
    [ "dictionary_hash", "group__ciniparser.html#ga7c1ef0a729e668d1e8d6a7e774feaf2e", null ],
    [ "dictionary_new", "group__ciniparser.html#ga876a908eb786f957f939a08a362e514d", null ],
    [ "dictionary_set", "group__ciniparser.html#gaab65a95ad09062716b24a129d8529b76", null ],
    [ "dictionary_unset", "group__ciniparser.html#ga27f0752948d52ccd2568dae22f5db2bc", null ]
];