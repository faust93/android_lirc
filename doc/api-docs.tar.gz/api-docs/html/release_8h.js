var release_8h =
[
    [ "check_release_event", "release_8h.html#a7522cb69a7da9186c7475485526d93bb", null ],
    [ "get_release_data", "release_8h.html#a23a8de91939f2b0c4ee9566e15f145d8", null ],
    [ "get_release_time", "release_8h.html#acd5db5a332efcd97e52621b7dc4db2a3", null ],
    [ "register_button_press", "release_8h.html#a3b06cf75f596a29a84d1137c05b62efe", null ],
    [ "register_input", "release_8h.html#a905c0feb9d5bf51f59e8e0db5c80ac69", null ],
    [ "release_map_remotes", "release_8h.html#a39a8c76eb6adaa95d03617c348a1fc09", null ],
    [ "set_release_suffix", "release_8h.html#a0b563b7d00f9d43c956701c496b6a5a6", null ],
    [ "trigger_release_event", "release_8h.html#ac2d85143861e84eb4893da33c6d1f3e3", null ]
];