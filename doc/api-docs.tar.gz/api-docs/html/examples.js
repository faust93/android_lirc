var examples =
[
    [ "drivers/default/Makefile", "drivers_2default_2Makefile-example.html", null ],
    [ "irexec.c", "irexec_8c-example.html", null ],
    [ "irsend.c", "irsend_8c-example.html", null ]
];