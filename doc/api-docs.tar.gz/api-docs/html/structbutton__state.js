var structbutton__state =
[
    [ "buffer", "structbutton__state.html#af23356c1f308bd3c3f3edfe14114c99b", null ],
    [ "count", "structbutton__state.html#ae9ac0a4d596bb5c957b448bab9d9f9a5", null ],
    [ "data", "structbutton__state.html#a3c68450cfb6f9d97f5d5e49911c12e5f", null ],
    [ "flag", "structbutton__state.html#a8b4a83330dbc73a8ecd3c99869548cce", null ],
    [ "message", "structbutton__state.html#a17bc72822e702c4a3fe59936c3f320c8", null ],
    [ "ncode", "structbutton__state.html#abcd54bc28722a363e84384100a35399a", null ],
    [ "no_data", "structbutton__state.html#a3ab351d154177785d9e4c25e84f2f1b0", null ],
    [ "retval", "structbutton__state.html#a46762a0d201da89a0f4c1e54ffd4f30d", null ],
    [ "string", "structbutton__state.html#a40d83693109f7959166f9df953cb5e11", null ],
    [ "sum", "structbutton__state.html#ab9ba4eb7e10e574771a2b3350f74b51c", null ]
];